import xbmcplugin, xbmcgui, sys

handle = int(sys.argv[1])

items = [
    ("🔥 Featured Content", ""),
    ("🎬 Trending", ""),
    ("⭐ Recommended", "")
]

for name, url in items:
    li = xbmcgui.ListItem(label=name)
    xbmcplugin.addDirectoryItem(handle, url, li, False)

xbmcplugin.endOfDirectory(handle)
