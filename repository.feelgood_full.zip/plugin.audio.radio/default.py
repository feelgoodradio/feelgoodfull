import xbmcplugin, xbmcgui, xbmc, sys

handle = int(sys.argv[1])

streams = [
    ("🎧 Feelgoodradio", "https://feelgoodradio.net/stream")
]

for name, url in streams:
    li = xbmcgui.ListItem(label=name)
    xbmcplugin.addDirectoryItem(handle, url, li, False)

xbmcplugin.endOfDirectory(handle)
